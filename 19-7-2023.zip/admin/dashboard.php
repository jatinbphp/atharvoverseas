<!DOCTYPE html>
<html lang="en">
<?php include('include/head.php') ?>
<?php include('include/navbar.php') ?>
<?php include('include/sidebar.php') ?>
<body class="hold-transition sidebar-mini layout-navbar-fixed">
<!-- wrapper -->
<div class="wrapper content-wrapper content-header">
    <!-- Main content -->
    <section class="content container-fluid">
        <!-- Main row -->
        <div class="row">
            <!-- Left col -->
            <section class="col-lg-7 connectedSortable">

            </section>
            <!-- /.Left col -->
            <!-- right col (We are only adding the ID to make the widgets sortable)-->
            <section class="col-lg-5 connectedSortable">


            </section>
            <!-- right col -->
        </div>
        <!-- /.row (main row) -->
    </section>
    <!-- /.content -->
</div>
<!-- ./wrapper -->
</body>
<?php include('include/footer.php') ?>
</html>
